﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicScript : MonoBehaviour
{    
    public AudioSource audioclip;
    // Start is called before the first frame update
    void Start()
    {
        audioclip = GetComponent<AudioSource>();
        audioclip.spatialBlend = 0;
        audioclip.volume = .7f;
        audioclip.playOnAwake = true;
        audioclip.loop = true;
    }
}
