﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStats : MonoBehaviour
{
    #region
    public static CharacterStats instance;
    #endregion


    // all initialization, must match values in Player
    public int maxHealth = 100;                 // player max health
    // player speed
    public float CmaxSpeed = 7f;                // direct influence of character speed
    private float CmaxSpeedHardCap = 10f;        // character speed cant pass this
    // jump focused
    public float CjumpTakeOffSpeed = 8;         // single jump height
    private float CjumpTakeOffHardCap = 11;     // single jump height cant pass this
    public int CmaxJumps = 1;                   // num jumps allowed before grounded
    private int CmaxJumpsHardCap = 3;           // num jumps allowed cant pass this
    // dash focused
    public int CdashTakeOffSpeed = 8;           // dash speed
    private int CdashTakeOffHardCap = 12;       // maximum allowed dash speed
    public float CdashCD = 3f;                  // dash cooldown
    private float CdashCDHardCap = .6f;         // minimum allowed dash cooldown

    public int currHealth {get; private set;}

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        currHealth = maxHealth;
    }

    // called from other script, parameter is amt of damage
    public void TakeDamage(int damage)
    {
        currHealth -= damage;
        if (currHealth <= 0)
            Death();
    }

    public void Death()
    {
        print("YOU DEAD");
    }

    public void GainHealth(int healing)
    {
        currHealth += healing;
        if (currHealth >= maxHealth)
            currHealth = maxHealth;
        print(currHealth);
    }

    public void GainMaxHealth(bool buffed, int healthBuff)
    {
        if (buffed)
        {
            maxHealth += healthBuff;
            currHealth = maxHealth;
        }

    }
    public void GainMoveSpeed(bool buffed)
    {
        if (buffed && CmaxSpeed < CmaxSpeedHardCap)
            CmaxSpeed += .5f;
    }
    public void GainJumpHeight(bool buffed)
    {
        if (buffed && CjumpTakeOffSpeed < CjumpTakeOffHardCap)
        {
            CjumpTakeOffSpeed+=.5f;
            if (CjumpTakeOffSpeed == CjumpTakeOffHardCap)
                print("Jump height is maxxed!");
        }
        else if (buffed && CjumpTakeOffSpeed == CjumpTakeOffHardCap)
            print("Jump height is already maxxed!!");
    }

    public void GainJumpCount(bool buffed)
    {
        if (buffed && CmaxJumps < CmaxJumpsHardCap)                     // this line runs when jumpCount can be upgraded
        {                                                               // on it's final itr, it will tell player they have reached max jump upgrade
            CmaxJumps++;
            if(CmaxJumps == CmaxJumpsHardCap)
                print("Super jump is maxxed!");
        }
        else if (buffed && CmaxJumps == CmaxJumpsHardCap)                // this line runs when jumpCount is maxxed
            print("Super jump is already maxxed!!");
    }

    public void GainDashDistance(bool buffed)
    {
        if (buffed && CdashTakeOffSpeed < CdashTakeOffHardCap)
            CdashTakeOffSpeed++;
    }

    public void GainDashCooldown(bool buffed)
    {
        if (buffed && CdashCD > CdashCDHardCap)
            CdashCD -= .3f;
    }
}
